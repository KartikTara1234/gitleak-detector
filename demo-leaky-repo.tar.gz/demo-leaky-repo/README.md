# Leaky Demo App

A deliberately insecure sample project used to demonstrate Repo Secret Sweeper.
Every credential in here is fake and was generated for the demo. None of them work.
