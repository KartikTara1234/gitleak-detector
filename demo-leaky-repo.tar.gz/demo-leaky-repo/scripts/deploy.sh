#!/bin/bash
# Deploy script
export SENDGRID_API_KEY="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"
curl https://deploy:Dep10yP4ss@ci.internal.corp/trigger
npm run build && npm run push
