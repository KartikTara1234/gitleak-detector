// Placeholder values — the scanner should rate these LOW, not critical
const defaults = { password: "changeme_please", token: "your_token_here_xxxx" };

// Real-looking hardcoded admin password — this SHOULD be flagged
const ADMIN = { user: "admin", password: "Tr0ub4dor&3xtra!" };

// A random-looking signing key with no known prefix — the entropy detector should catch it
const HMAC_SIGNING_KEY = "qZ8vN2xK7mP4wL9sR3tY6uH1jF5gD0aB";

module.exports = { ADMIN, defaults, HMAC_SIGNING_KEY };
