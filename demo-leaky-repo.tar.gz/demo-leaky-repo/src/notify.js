const SLACK_WEBHOOK = "https://hooks.slack.com/services/T0DEMO1234/B0DEMO5678/d3m0W3bh00kT0k3nAbCdEfGh";
const TELEGRAM_BOT = "123456789:AAFd3m0b0tt0k3nF0rSw33p3rT3st1ngX00";

async function send(msg) {
  await fetch(SLACK_WEBHOOK, { method: 'POST', body: JSON.stringify({ text: msg }) });
}
module.exports = { send };
