const { Client } = require('pg');

// TODO: stop hardcoding this
const client = new Client({
  connectionString: 'postgres://app_user:Pr0dP4ssw0rd!@db.internal.corp:5432/app',
});

const redis = require('redis').createClient({ url: 'redis://:r3d1sP4ss@cache.internal:6379' });

module.exports = { client, redis };
