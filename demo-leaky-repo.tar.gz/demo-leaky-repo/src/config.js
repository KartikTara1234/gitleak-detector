// Legacy config — "we'll move these to env vars later"
module.exports = {
  aws: {
    accessKeyId: "AKIAIOSFODNN7DEMOKEY",
    aws_secret_access_key: "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",
    region: "ap-south-1",
  },
  github: {
    token: "ghp_K9mX2vL7qP4wR8tY3uH6jF1gD5sA0bNcE2fG",
  },
  google: {
    mapsKey: "AIzaSyB7kL2mN9pQ4rS6tV8wX1yZ3aC5dE7fG9h",
  },
  // This one is fine — it's read from the environment
  sessionSecret: process.env.SESSION_SECRET,
};
