import OpenAI from "openai";
import Anthropic from "@anthropic-ai/sdk";

// Both of these should be in env vars
const openai = new OpenAI({ apiKey: "sk-proj-K3mN8pQ2rS5tV9wX1yZ4aC7dE0fG3hJ6kL9mN2pQ5rS8tV1wX4yZ" });
const anthropic = new Anthropic({ apiKey: "sk-ant-api03-K3mN8pQ2rS5tV9wX1yZ4aC7dE0fG3hJ6kL9mN2pQ5rS8tV1wX4yZ7aC0dE" });

export { openai, anthropic };
